#!/bin/bash

if [ ! -f ".env" ]; then
    echo ".env file not found!"
    exit 1
fi

export $(grep -v '^#' .env | xargs)

# Check if GOOGLE_API_KEY is set
if [ -z "$GOOGLE_API_KEY" ]; then
    echo "GOOGLE_API_KEY is not set in the .env file. ADD IT Y'ALL."
    exit 1
fi

echo "Installing Python dependencies..."
pip install -r requirements.txt

# Step 2: Set up Ngrok authtoken
if [ -z "$NGROK_AUTHTOKEN" ]; then
    echo "NGROK_AUTHTOKEN not set in .env. SET IT UP!!!."
    exit 1
fi

echo "Configuring Ngrok authtoken..."
ngrok config add-authtoken $NGROK_AUTHTOKEN

echo "Running the application..."
python run.py


